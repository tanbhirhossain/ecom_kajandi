<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AndroidIphone extends Model
{
    //
}
