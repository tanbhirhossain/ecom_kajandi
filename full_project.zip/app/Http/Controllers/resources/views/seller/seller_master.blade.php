@include('seller.includes.header')

@yield('seller_content')

@include('seller.includes.footer')
