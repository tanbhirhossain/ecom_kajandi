<h6 class="title-divider text-muted mt40 mb20"> Site Statistics
    <span class="pull-right text-primary fw600">Today</span>
</h6>
</div>
</div>
</aside>
<!--  /Sidebar Right  -->

</div>
<!--  /Body Wrap   -->

<!--  Scripts  -->

<!--  jQuery  -->
<script src="{{asset('public/seller')}}/assets/js/jquery/jquery-1.11.3.min.js"></script>
<script src="{{asset('public/seller')}}/assets/js/jquery/jquery_ui/jquery-ui.min.js"></script>

<script src="{{asset('public/seller')}}/assets/js/plugins/fileupload/fileupload.js"></script>
<script src="{{asset('public/seller')}}/assets/js/plugins/holder/holder.min.js"></script>


<!--  HighCharts Plugin  -->
<script src="{{asset('public/seller')}}/assets/js/plugins/highcharts/highcharts.js"></script>
<script src="{{asset('public/seller')}}/assets/js/plugins/c3charts/d3.min.js"></script>
<script src="{{asset('public/seller')}}/assets/js/plugins/c3charts/c3.min.js"></script>

<!--  Simple Circles Plugin  -->
<script src="{{asset('public/seller')}}/assets/js/plugins/circles/circles.js"></script>

<!--  Maps JSs  -->
<script src="{{asset('public/seller')}}/assets/js/plugins/jvectormap/jquery.jvectormap.min.js"></script>
<script src="{{asset('public/seller')}}/assets/js/plugins/jvectormap/assets/jquery-jvectormap-us-lcc-en.js"></script>

<!--  FullCalendar Plugin  -->
<script src="{{asset('public/seller')}}/assets/js/plugins/fullcalendar/lib/moment.min.js"></script>
<script src="{{asset('public/seller')}}/assets/js/plugins/fullcalendar/fullcalendar.min.js"></script>

<!--  Date/Month - Pickers  -->
<script src="{{asset('public/seller')}}/assets/allcp/forms/js/jquery-ui-monthpicker.min.js"></script>
<script src="{{asset('public/seller')}}/assets/allcp/forms/js/jquery-ui-datepicker.min.js"></script>

<!--  Magnific Popup Plugin  -->
<script src="{{asset('public/seller')}}/assets/js/plugins/magnific/jquery.magnific-popup.js"></script>

<!--  Theme Scripts  -->
<script src="{{asset('public/seller')}}/assets/js/utility/utility.js"></script>
<script src="{{asset('public/seller')}}/assets/js/demo/demo.js"></script>
<script src="{{asset('public/seller')}}/assets/js/main.js"></script>

<!--  Widget JS  -->
<script src="{{asset('public/seller')}}/assets/js/demo/widgets.js"></script>
<script src="{{asset('public/seller')}}/assets/js/demo/widgets_sidebar.js"></script>
<script src="{{asset('public/seller')}}/assets/js/pages/dashboard1.js"></script>
<!--  /Scripts  -->

</body>

</html>
