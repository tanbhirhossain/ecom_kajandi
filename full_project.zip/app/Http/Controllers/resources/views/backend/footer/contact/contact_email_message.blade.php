
    <h2 style="color:green">Email Template</h2>
    <h4 style="color: yellow">{{$subject}}</h4>
    <article style="font-size: 20px;color: #0a95be">
        {!! $content !!}
    </article>
    <footer style="color: #0a95be">
        <a href="http://kajandi.com" style="color: #0a95be"> Mail From Kajandi Shop</a>
    </footer>
