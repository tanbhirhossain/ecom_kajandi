<h2>Admin Panel Email is: {{$email}}</h2>
<h3>Admin Panel Password is: {{$password}}</h3>